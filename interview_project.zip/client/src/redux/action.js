export const saveData = (data) => ({ type: "saveData", payload: data });
